# Phần 3: Phân tích và mô hình hóa
md("""
## 3. PHÂN TÍCH VÀ MÔ HÌNH HÓA

### 3.1. Thước đo đánh giá
Với 3 lớp và ~90% là lớp Tích cực, Accuracy rất dễ gây hiểu nhầm. Nhóm báo cáo đủ 5 thước đo theo yêu cầu đề bài, tính **trung bình macro**
(mỗi lớp có trọng số bằng nhau, nên lớp hiếm không bị lớp đông "nuốt"):
- **F1 macro** — thước đo chính để chọn mô hình (cân bằng Precision và Recall, công bằng giữa 3 lớp).
- **Precision macro, Recall macro, Accuracy.**
- **ROC-AUC macro (one-vs-rest)** — khả năng xếp hạng, không phụ thuộc ngưỡng; tính từ xác suất hoặc `decision_function` (với LinearSVC).
- **F1 lớp Trung tính** — theo dõi riêng vì đây là lớp khó nhất và hiếm nhất.

### 3.2. Baseline và so sánh các mô hình (trên Validation)
- **Baseline 1 — Dummy:** luôn đoán lớp đa số.
- **Baseline 2 — Logistic Regression** tham số mặc định, không xử lý mất cân bằng.
- **3 thuật toán theo đề:** MultinomialNB, Logistic Regression, LinearSVC — mỗi thuật toán chạy **hai phiên bản**: mặc định và phiên bản xử lý mất cân bằng
  (`class_weight='balanced'` cho LogReg/LinearSVC; `fit_prior=False` cho MultinomialNB, tức là dùng xác suất tiên nghiệm đều thay vì theo tần suất lớp).
""")

code(r"""
CLASSES = [0, 1, 2]


def get_scores(model, X):
    # Điểm số theo lớp: xác suất nếu có, ngược lại dùng decision_function (LinearSVC).
    return model.predict_proba(X) if hasattr(model, 'predict_proba') else model.decision_function(X)


def macro_auc(y_true, scores):
    Y = label_binarize(y_true, classes=CLASSES)
    return float(np.mean([roc_auc_score(Y[:, k], scores[:, k]) for k in CLASSES]))


def evaluate(model, X, y_true):
    pred = model.predict(X)
    return {'Accuracy': accuracy_score(y_true, pred),
            'Precision': precision_score(y_true, pred, average='macro', zero_division=0),
            'Recall': recall_score(y_true, pred, average='macro', zero_division=0),
            'F1': f1_score(y_true, pred, average='macro', zero_division=0),
            'ROC-AUC': macro_auc(y_true, get_scores(model, X)),
            'F1 Trung tính': f1_score(y_true, pred, labels=[1], average='macro', zero_division=0)}


METRIC_FMT = {c: '{:.3f}' for c in ['Accuracy', 'Precision', 'Recall', 'F1', 'ROC-AUC', 'F1 Trung tính']}

ALGORITHMS = {
    'MultinomialNB': {'default': lambda: MultinomialNB(), 'balanced': lambda: MultinomialNB(fit_prior=False)},
    'LogisticRegression': {'default': lambda: LogisticRegression(max_iter=2000),
                           'balanced': lambda: LogisticRegression(max_iter=2000, class_weight='balanced')},
    'LinearSVC': {'default': lambda: LinearSVC(random_state=RANDOM_STATE),
                  'balanced': lambda: LinearSVC(class_weight='balanced', random_state=RANDOM_STATE)},
}

models = {'Dummy (lớp đa số)': make_pipeline(DummyClassifier(strategy='most_frequent'))}
for name, versions in ALGORITHMS.items():
    models[name] = make_pipeline(versions['default']())
    models[f'{name} + balanced'] = make_pipeline(versions['balanced']())

val_rows = []
for name, model in models.items():
    model.fit(X_train, y_train)
    val_rows.append({'Mô hình': name, **evaluate(model, X_val, y_val)})
val_results = pd.DataFrame(val_rows).set_index('Mô hình')
display(val_results.style.format(METRIC_FMT).highlight_max(color='#c6efce', axis=0))
""")

md("""
**Câu hỏi: xử lý mất cân bằng thay đổi F1 macro và F1 lớp Trung tính của từng thuật toán thế nào?**
""")

code(r"""
plot_rows = []
for name in ALGORITHMS:
    for suffix, label in [('', 'Mặc định'), (' + balanced', 'Xử lý mất cân bằng')]:
        r = val_results.loc[name + suffix]
        plot_rows += [{'Thuật toán': name, 'Phiên bản': label, 'Metric': m, 'Giá trị': r[m]} for m in ['F1', 'F1 Trung tính']]
plot_df = pd.DataFrame(plot_rows)

g = sns.catplot(data=plot_df, x='Thuật toán', y='Giá trị', hue='Phiên bản', col='Metric', kind='bar',
                palette=['#BBBBBB', '#DD5145'], height=4, aspect=1.4)
for ax in g.axes.flat:
    for c in ax.containers:
        ax.bar_label(c, fmt='%.2f', fontsize=9)
    ax.set_ylim(0, 1)
g.figure.suptitle('Validation: ảnh hưởng của việc xử lý mất cân bằng lên F1 macro và F1 lớp Trung tính', y=1.05)
plt.show()
""")

md(note("VAL"))

md("""
### 3.3. Tinh chỉnh siêu tham số (GridSearchCV, 5-fold phân tầng trên Train)
Tinh chỉnh cả 3 thuật toán; cấu hình TF-IDF được giữ cố định đúng như đề (`max_features=5000`, `ngram_range=(1, 2)`).
Việc xử lý mất cân bằng (`class_weight` / `fit_prior`) được coi là một siêu tham số; tiêu chí chọn là **F1 macro**.
Quá trình tìm kiếm chỉ dùng Train (cross-validation); Validation chỉ dùng để so sánh các mô hình đã tuning.
""")

code(r"""
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
GRIDS = {
    'MultinomialNB': (MultinomialNB(), {'clf__alpha': [0.05, 0.1, 0.3, 1.0], 'clf__fit_prior': [True, False]}),
    'LogisticRegression': (LogisticRegression(max_iter=2000),
                           {'clf__C': [0.3, 1, 3, 10, 30], 'clf__class_weight': [None, 'balanced']}),
    'LinearSVC': (LinearSVC(random_state=RANDOM_STATE),
                  {'clf__C': [0.03, 0.1, 0.3, 1, 3], 'clf__class_weight': [None, 'balanced']}),
}

tuned, tune_rows = {}, []
for name, (clf, grid) in GRIDS.items():
    search = GridSearchCV(make_pipeline(clf), grid, scoring='f1_macro', cv=cv, n_jobs=-1).fit(X_train, y_train)
    tuned[name] = search.best_estimator_
    tune_rows.append({'Mô hình': f'{name} (tuned)', 'CV F1': search.best_score_, **evaluate(tuned[name], X_val, y_val),
                      'Tham số tốt nhất': {k.replace('clf__', ''): v for k, v in search.best_params_.items()}})
tune_results = pd.DataFrame(tune_rows).set_index('Mô hình')
display(tune_results.drop(columns='Tham số tốt nhất').style.format({**METRIC_FMT, 'CV F1': '{:.3f}'}).highlight_max(color='#c6efce', axis=0))
for name, params in tune_results['Tham số tốt nhất'].items():
    print(f'{name}: {params}')
""")

md(note("TUNE"))

md("""
### 3.4. Thử nghiệm: thêm đặc trưng số (meta-features) có giúp ích không?
Với hai mô hình tuyến tính tốt nhất (MultinomialNB không dùng được vì `StandardScaler` tạo giá trị âm), nhóm giữ nguyên siêu tham số đã tuning
và so sánh **chỉ-TF-IDF** với **TF-IDF + 8 đặc trưng số** (đã điền thiếu, `log1p` cho nhóm đếm/tỉ lệ, `StandardScaler`) trên cùng tập Validation.
""")

code(r"""
meta_rows, tuned_meta = [], {}
for name in ['LogisticRegression', 'LinearSVC']:
    best_clf = clone(tuned[name].named_steps['clf'])
    tuned_meta[name] = make_pipeline(best_clf, use_meta=True).fit(X_train, y_train)
    for label, model in [('chỉ TF-IDF', tuned[name]), ('TF-IDF + meta-features', tuned_meta[name])]:
        meta_rows.append({'Mô hình': f'{name} ({label})', **evaluate(model, X_val, y_val)})
meta_results = pd.DataFrame(meta_rows).set_index('Mô hình')
display(meta_results.style.format(METRIC_FMT).highlight_max(color='#c6efce', axis=0))
""")

md(note("META"))

md("""
### 3.5. Chọn mô hình cuối (dựa trên Validation, không dùng Test)
Mô hình cuối là mô hình có **F1 macro cao nhất trên Validation** trong số các cấu hình đã tuning (có hoặc không có meta-features).
""")

code(r"""
candidates = {f'{n} (tuned)': m for n, m in tuned.items()}
candidates.update({f'{n} (tuned + meta)': m for n, m in tuned_meta.items()})
cand_val = pd.DataFrame({k: evaluate(m, X_val, y_val) for k, m in candidates.items()}).T.sort_values('F1', ascending=False)
display(cand_val.style.format(METRIC_FMT).highlight_max(color='#c6efce', axis=0))

best_name = cand_val.index[0]
final_model = candidates[best_name]
print(f'Mô hình cuối (chọn theo F1 macro trên Validation): {best_name}')
print('Siêu tham số:', {k: v for k, v in final_model.named_steps['clf'].get_params().items() if k in ('C', 'alpha', 'class_weight', 'fit_prior')})
""")

md(note("FINAL"))
