# Phần 2: Chuẩn bị dữ liệu
md("""
## 2. CHUẨN BỊ DỮ LIỆU

Nguyên tắc: mọi bước **có học tham số từ dữ liệu** (từ vựng và IDF của TF-IDF, median để điền thiếu, trung bình/độ lệch chuẩn để scale)
đều nằm trong `Pipeline` và chỉ được `fit` trên tập **Train** → tránh rò rỉ dữ liệu (data leakage) sang Validation/Test.
Riêng bước làm sạch văn bản không học tham số từ dữ liệu nên được đóng gói thành một lớp `TextCleaner` dùng lại được (OOP).

### 2.1. Xử lý giá trị thiếu, trùng lặp, loại cột không dùng và gán nhãn
""")

code(r"""
n_raw = len(raw)
data = raw.copy()

# (1) Giá trị thiếu: không thể phân loại cảm xúc khi không có nội dung -> xóa dòng thiếu reviewText.
data = data.dropna(subset=['reviewText'])
n_after_na = len(data)

# (2) Trùng lặp: xóa đánh giá có nội dung giống hệt (giữ bản đầu) để không bị lặp giữa Train và Test.
data = data.drop_duplicates(subset='reviewText')
n_after_dup = len(data)

# (3) Loại cột không dùng: định danh, ngày đăng, và 3 cột suy ra từ cột bình chọn (trùng thông tin).
DROP_COLS = ['Unnamed: 0', 'reviewerName', 'reviewTime', 'score_pos_neg_diff', 'score_average_rating', 'wilson_lower_bound']
data = data.drop(columns=DROP_COLS)

# (4) Gán nhãn cảm xúc từ điểm sao rồi bỏ cột overall khỏi đặc trưng (tránh rò rỉ nhãn).
data['label'] = data['overall'].map(rating_to_label)
stars = data['overall'].astype(int)
data = data.drop(columns='overall').reset_index(drop=True)
stars = stars.reset_index(drop=True)
TARGET = 'label'

print(f'Ban đầu: {n_raw:,} dòng | sau khi xóa thiếu reviewText: {n_after_na:,} (-{n_raw - n_after_na}) | '
      f'sau khi xóa trùng: {n_after_dup:,} (-{n_after_na - n_after_dup})')
print(f'Cột còn lại: {list(data.columns)}')
print(f'Còn giá trị thiếu không: {int(data.isna().sum().sum())}')
display(data['label'].map(CLASS_NAMES).value_counts().to_frame('Số mẫu').assign(**{'Tỉ lệ': lambda d: d['Số mẫu'] / len(data)}))
""")

md(note("CLEAN"))

md("""
### 2.2. Chia tập Train / Validation / Test (70 / 15 / 15, phân tầng theo nhãn)
- **Train:** huấn luyện. **Validation:** so sánh mô hình, chọn cấu hình. **Test:** chỉ dùng **một lần** ở Phần 4.
- `stratify=y` giữ tỉ lệ ba lớp ở cả ba tập (quan trọng vì lớp Trung tính rất hiếm). Chia **trước** khi fit TF-IDF/scaler để tránh rò rỉ.
""")

code(r"""
BASE_COLS = ['reviewText', 'day_diff', 'helpful_yes', 'helpful_no', 'total_vote']
X, y = data[BASE_COLS], data[TARGET]
X_train, X_tmp, y_train, y_tmp = train_test_split(X, y, test_size=0.30, stratify=y, random_state=RANDOM_STATE)
X_val, X_test, y_val, y_test = train_test_split(X_tmp, y_tmp, test_size=0.50, stratify=y_tmp, random_state=RANDOM_STATE)

split_df = pd.DataFrame({name: {'Số mẫu': len(t), 'Tỉ lệ': len(t) / len(X), **{f'% {CLASS_NAMES[k]}': (t == k).mean() * 100 for k in range(3)},
                                **{f'Số {CLASS_NAMES[k]}': int((t == k).sum()) for k in range(3)}}
                        for name, t in [('Train', y_train), ('Validation', y_val), ('Test', y_test)]}).T
display(split_df)
""")

md("""
### 2.3. Làm sạch văn bản bằng lớp `TextCleaner`
| Bước | Lý do |
|---|---|
| Chuyển chữ thường, xóa thẻ HTML và URL | Đồng nhất từ vựng (`Great` = `great`), bỏ nhiễu không mang cảm xúc |
| Mở rộng dạng viết tắt phủ định (`don't` → `do not`, `can't` → `can not`, `won't` → `will not`) | Giữ lại **từ phủ định**: `not good` và `good` có cảm xúc ngược nhau |
| Chỉ giữ chữ cái, bỏ số và dấu câu | Giảm nhiễu; số lượng dấu `!` được giữ lại ở dạng đặc trưng số (mục 2.4) |
| Loại stop words **nhưng giữ từ phủ định và từ nhấn mạnh** (`not`, `no`, `never`, `but`, `very`, `too`, `only`...) | Danh sách stop words chuẩn của scikit-learn chứa các từ này, nếu bỏ sẽ mất tín hiệu cảm xúc |
""")

code(r"""
# Từ vựng có mang tín hiệu cảm xúc nhưng nằm trong danh sách stop words chuẩn -> giữ lại.
KEEP_WORDS = {'no', 'not', 'nor', 'never', 'none', 'nobody', 'nothing', 'neither', 'cannot', 'without', 'but', 'very', 'too', 'only', 'enough', 'more', 'most', 'less', 'least', 'few', 'much', 'however', 'although', 'though', 'against', 'well'}
STOP_WORDS = frozenset(ENGLISH_STOP_WORDS) - KEEP_WORDS


class TextCleaner(BaseEstimator, TransformerMixin):
    # Làm sạch văn bản tiếng Anh; không học tham số nên fit() không làm gì (an toàn với cross-validation).
    def __init__(self, remove_stopwords=True, min_len=2):
        self.remove_stopwords = remove_stopwords
        self.min_len = min_len

    def fit(self, X, y=None):
        return self

    def clean_one(self, text):
        text = str(text).lower().replace('’', "'")
        text = re.sub(r'<[^>]+>', ' ', text)                    # thẻ HTML
        text = re.sub(r'http\S+|www\.\S+', ' ', text)           # URL
        text = text.replace("won't", 'will not').replace("can't", 'can not')
        text = re.sub(r"n't\b", ' not', text)                   # don't -> do not
        text = re.sub(r"'(?:m|re|ve|ll|d|s)\b", ' ', text)      # 'm 're 've 'll 'd 's
        text = re.sub(r'[^a-z\s]', ' ', text)                   # bỏ số và dấu câu
        tokens = [w for w in text.split() if len(w) >= self.min_len]
        if self.remove_stopwords:
            tokens = [w for w in tokens if w not in STOP_WORDS]
        return ' '.join(tokens)

    def transform(self, X):
        return [self.clean_one(t) for t in pd.Series(X).fillna('')]


cleaner = TextCleaner()
demo = data.sample(4, random_state=7)['reviewText']
display(pd.DataFrame({'Trước': demo.values, 'Sau khi làm sạch': cleaner.transform(demo)}))
print("Kiểm tra phủ định:", cleaner.transform(["It doesn't work and I can't recommend it!", "Works great, I'm very happy."]))
""")

code(r"""
# Kiểm tra sau làm sạch (chỉ dùng tập TRAIN): độ dài, và các từ đặc trưng nhất của mỗi lớp (log-odds, chỉ để khám phá).
train_text = pd.DataFrame({'raw': X_train['reviewText'], 'clean': cleaner.transform(X_train['reviewText']), 'label': y_train})
print(f"Số từ trung bình: trước = {train_text['raw'].str.split().str.len().mean():.1f} | "
      f"sau = {train_text['clean'].str.split().str.len().mean():.1f}")
print(f"Số đánh giá rỗng sau làm sạch: {(train_text['clean'].str.strip() == '').sum()}")

cv = CountVectorizer(min_df=5, binary=True)
B = cv.fit_transform(train_text['clean'])
vocab = np.array(cv.get_feature_names_out())
doc_freq = {k: np.asarray(B[(train_text['label'] == k).values].sum(axis=0)).ravel() + 1 for k in range(3)}
n_docs = {k: int((train_text['label'] == k).sum()) + 2 for k in range(3)}
fig, axes = plt.subplots(1, 3, figsize=(20, 5))
top_words = {}
for k, ax in zip(range(3), axes):
    rest = sum(doc_freq[j] for j in range(3) if j != k)
    n_rest = sum(n_docs[j] for j in range(3) if j != k)
    logodds = np.log(doc_freq[k] / n_docs[k]) - np.log(rest / n_rest)
    idx = np.argsort(logodds)[::-1][:12]
    top_words[k] = list(vocab[idx])
    ax.barh(vocab[idx][::-1], logodds[idx][::-1], color=CLASS_COLORS[k])
    ax.set(title=f'Từ đặc trưng nhất: {CLASS_NAMES[k]}', xlabel='log-odds so với các lớp còn lại')
plt.tight_layout(); plt.show()
for k in range(3):
    print(f'{CLASS_NAMES[k]:11s}:', ', '.join(top_words[k]))
""")

md(note("WORDS"))

md("""
### 2.4. Đặc trưng số bổ sung (meta-features) và Pipeline tiền xử lý
Ngoài TF-IDF, nhóm thử thêm 8 đặc trưng số: 4 cột có sẵn (`day_diff`, `helpful_yes`, `helpful_no`, `total_vote`) và 4 đặc trưng tính từ văn bản
(`word_count`, `char_count`, `exclaim_count` = số dấu `!`, `upper_ratio` = tỉ lệ chữ in hoa). Mục 3 sẽ kiểm tra bằng thực nghiệm xem chúng có giúp ích không.

| Nhánh | Missing | Outlier / Scaling | Encoding |
|---|---|---|---|
| Văn bản (`reviewText`) | `TextCleaner` thay thiếu bằng chuỗi rỗng | — | `TfidfVectorizer(max_features=5000, ngram_range=(1, 2), min_df=2, sublinear_tf=True)` |
| Số, nhóm đếm/tỉ lệ (7 cột: `helpful_yes`, `helpful_no`, `total_vote`, `word_count`, `char_count`, `exclaim_count`, `upper_ratio`) | median (từ Train) | `log1p` để nén đuôi phải, rồi **StandardScaler** | — |
| Số, nhóm thời gian (`day_diff`) | median (từ Train) | chỉ **StandardScaler** (đã gần đối xứng, `log1p` sẽ làm lệch trái) | — |
| Nhãn (`label`) | — | — | Mã hóa thứ bậc 0 < 1 < 2 theo mức độ cảm xúc (Ordinal Encoding) |

Kiểm tra lý do chọn cách scale trước khi dựng pipeline:
""")

code(r"""
def add_meta_features(X):
    X = X.copy()
    text = X['reviewText'].fillna('')
    X['word_count'] = text.str.split().str.len()
    X['char_count'] = text.str.len()
    X['exclaim_count'] = text.str.count('!')
    X['upper_ratio'] = text.apply(lambda t: sum(c.isupper() for c in t) / max(len(t), 1))
    return X


LOG_COLS = ['helpful_yes', 'helpful_no', 'total_vote', 'word_count', 'char_count', 'exclaim_count', 'upper_ratio']
PLAIN_COLS = ['day_diff']
NUM_COLS = PLAIN_COLS + LOG_COLS
meta_train = add_meta_features(X_train)[NUM_COLS]

q = meta_train.quantile([.25, .5, .75, .99]).T
q['IQR'] = q[0.75] - q[0.25]
q['Skew'] = meta_train.skew()
q['Skew sau biến đổi'] = [np.log1p(meta_train[c]).skew() if c in LOG_COLS else meta_train[c].skew() for c in q.index]
q['Biến đổi'] = ['log1p + scale' if c in LOG_COLS else 'chỉ scale' for c in q.index]
display(q.rename(columns={0.25: 'Q1', 0.5: 'Median', 0.75: 'Q3', 0.99: 'P99'}))

fig, axes = plt.subplots(2, 3, figsize=(18, 7))
for j, c in enumerate(['word_count', 'total_vote', 'day_diff']):
    v = meta_train[c]
    axes[0, j].hist(v, bins=50, color='#C44E52'); axes[0, j].set_title(f'{c}: gốc (skew={v.skew():.2f})')
    base = np.log1p(v.to_frame()) if c in LOG_COLS else v.to_frame()
    s = StandardScaler().fit_transform(base)
    how = 'log1p + StandardScaler' if c in LOG_COLS else 'StandardScaler'
    axes[1, j].hist(s, bins=50, color='#4C72B0'); axes[1, j].set_title(f'{c}: {how} (skew={pd.Series(s.ravel()).skew():.2f})')
plt.tight_layout(); plt.show()
""")

md(note("PREP"))

code(r"""
def build_preprocessor(use_meta=False):
    # Nhánh văn bản: làm sạch -> TF-IDF. Nhánh số (tùy chọn): điền thiếu -> (log1p) -> StandardScaler.
    text_branch = Pipeline([
        ('clean', TextCleaner()),
        ('tfidf', TfidfVectorizer(max_features=5000, ngram_range=(1, 2), min_df=2, sublinear_tf=True)),
    ])
    transformers = [('text', text_branch, 'reviewText')]
    if use_meta:
        log_branch = Pipeline([
            ('impute', SimpleImputer(strategy='median')),
            ('log1p', FunctionTransformer(np.log1p)),
            ('scale', StandardScaler()),
        ])
        plain_branch = Pipeline([
            ('impute', SimpleImputer(strategy='median')),
            ('scale', StandardScaler()),
        ])
        transformers += [('num_log', log_branch, LOG_COLS), ('num_plain', plain_branch, PLAIN_COLS)]
    return ColumnTransformer(transformers)


def make_pipeline(clf, use_meta=False):
    steps = []
    if use_meta:
        steps.append(('meta', FunctionTransformer(add_meta_features)))   # tạo meta-features từ dữ liệu thô
    steps += [('prep', build_preprocessor(use_meta)), ('clf', clf)]
    return Pipeline(steps)


demo_pipe = make_pipeline(LogisticRegression(max_iter=2000), use_meta=True).fit(X_train, y_train)
Z = demo_pipe[:-1].transform(X_train)
print(f'Ma trận đặc trưng Train: {Z.shape[0]:,} mẫu × {Z.shape[1]:,} đặc trưng '
      f'(5,000 TF-IDF + {len(NUM_COLS)} số) | độ thưa: {1 - Z.nnz / (Z.shape[0] * Z.shape[1]):.1%}')
""")

md(note("PREP2"))
