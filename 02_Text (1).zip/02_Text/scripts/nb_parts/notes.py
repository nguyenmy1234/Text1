# Nhận xét (markdown) chèn sau các ô code của notebook. Mỗi khóa được gọi bằng note("KHÓA") trong các part.
# Mọi con số dưới đây lấy từ lần chạy thực tế (random_state=42); chạy lại với phiên bản thư viện khác có thể lệch nhẹ ở chữ số thập phân cuối.
NOTES = {
"MISSING": """
> **Nhận xét:**
> - Dữ liệu gần như đầy đủ: chỉ **2/4,915 dòng (0.04%)** có ô thiếu: 1 dòng thiếu `reviewText` và 1 dòng thiếu `reviewerName` (cột định danh, sẽ bị loại).
> - Dòng thiếu `reviewText` không thể phân loại cảm xúc nên sẽ bị **xóa** (không điền bù).
> - Có **2 đánh giá trùng nội dung** (`reviewText` giống hệt) → xóa bản lặp để cùng một câu không rơi vào cả Train lẫn Test.
""",
"TARGET": """
> **Nhận xét:**
> - Điểm sao lệch hẳn về cao: **4–5 sao chiếm 4,448/4,914 (90.5%)**, 1–2 sao chỉ 324 (6.6%), 3 sao chỉ 142 (2.9%).
> - Tỉ lệ lớp đa số / thiểu số = **31.3 : 1**. Một mô hình "luôn đoán Tích cực" đạt Accuracy **0.905** nhưng F1 macro chỉ **0.317** → Accuracy không đủ để đánh giá; F1 macro được chọn làm thước đo chính.
> - Lớp **Trung tính chỉ có 142 mẫu** (khoảng 99 mẫu ở Train, 21–22 mẫu ở Validation/Test), nên mọi chỉ số của lớp này rất nhiễu.
""",
"LENGTH": """
> **Nhận xét:**
> - Độ dài rất lệch phải (skewness = **8.48**): trung bình 50 từ nhưng dài nhất 1,554 từ.
> - Người viết đánh giá **tiêu cực viết dài hơn rõ rệt**: trung bình 106.5 từ (median 78) so với 73.3 (median 50) ở Trung tính và 45.6 (median 31) ở Tích cực, tức dài gấp khoảng 2.3–2.5 lần lớp Tích cực.
> - Độ dài vì vậy có tín hiệu, nhưng hai phân phối chồng lấn nhiều (xem biểu đồ log), không đủ để tự phân loại. Dùng `log1p` khi đưa vào mô hình để nén đuôi phải.
""",
"CORR": """
> **Nhận xét:**
> - `word_count` và `char_count` gần như trùng nhau (ρ = **0.979**); `helpful_yes`/`helpful_no` đều tương quan mạnh với `total_vote` (0.853 và 0.653) → các cột này mang thông tin chồng lấn.
> - `overall` chỉ tương quan **yếu** với các cột còn lại, mạnh nhất cũng chỉ |ρ| = 0.256 (`helpful_no`, âm), rồi `total_vote` (−0.222), `char_count` (−0.218), `word_count` (−0.216). Đánh giá điểm thấp thường dài hơn và nhận nhiều bình chọn hơn.
> - `exclaim_count` (+0.054) và `day_diff` (−0.063) gần như không liên quan. Không đặc trưng số nào đủ mạnh để đoán cảm xúc → thông tin chính nằm ở **nội dung văn bản**.
""",
"OUTLIER": """
> **Nhận xét:**
> - Các cột đếm có nhiều outlier theo IQR: `word_count` 452 (9.2%), `char_count` 464 (9.4%), `exclaim_count` 807 (16.4%), `helpful_yes` 412 (8.4%), `helpful_no` 240 (4.9%), `total_vote` 554 (11.3%).
> - Với 3 cột bình chọn, IQR = 0 vì hơn 75% đánh giá không có phiếu nào, nên mọi giá trị khác 0 đều bị tính là outlier (skewness 30–40).
> - Đây là **giá trị thật** (đánh giá dài, đánh giá được nhiều người bình chọn), không phải lỗi nhập liệu → **không xóa**, mà nén bằng `log1p` ở bước tiền xử lý. `day_diff` không có outlier (skew = 0.14).
""",
"EDA": """
> **Nhận xét:**
> - **Tỉ lệ tiêu cực giảm dần theo năm đăng**: 62/500 = 12.4% (2012), 195/2,678 = 7.3% (2013), 67/1,736 = 3.9% (2014). Tỉ lệ Trung tính ổn định khoảng 2.6–3.1%.
> - Đánh giá **tiêu cực nhận nhiều bình chọn hơn hẳn**: trung bình 7.96 phiếu/đánh giá so với 1.08 (Tích cực) và 0.54 (Trung tính); đánh giá tiêu cực cũng cũ hơn (day_diff trung bình 514 so với 431).
> - **Bằng chứng về miền sản phẩm:** 51.5% đánh giá nhắc từ "card/cards" và 76.4% nhắc ít nhất một từ khóa thẻ nhớ (card, SD, micro, memory, storage, GB, SanDisk, Samsung) → dữ liệu chủ yếu về **thẻ nhớ**, nên từ vựng mô hình học được rất đặc thù (ảnh hưởng đến kết quả ở mục 4.5).
""",
"CLEAN": """
> **Nhận xét:** Sau khi xóa 1 dòng thiếu `reviewText` và 2 dòng trùng, còn **4,912 đánh giá** (giữ 99.94%) với 6 cột (5 đặc trưng gốc + nhãn), không còn giá trị thiếu.
> Phân bố nhãn gần như không đổi: **Tích cực 4,446 (90.5%)**, **Tiêu cực 324 (6.6%)**, **Trung tính 142 (2.9%)**.
""",
"WORDS": """
> **Nhận xét:**
> - Làm sạch giảm độ dài trung bình từ **50.9 xuống 25.0 từ** (khoảng một nửa) và không tạo ra đánh giá rỗng nào. Kiểm tra phủ định cho thấy `doesn't work ... can't recommend` được giữ thành `does not work not recommend`.
> - Từ đặc trưng **Tiêu cực** rất rõ nghĩa: *refund, dead, dud, unreadable, avoid, upset* (hỏng, đòi hoàn tiền). Từ đặc trưng **Tích cực**: *highly, easy, great, perfect, nice, best, pleased, fast*.
> - Danh sách **Trung tính** nhiễu và ít nghĩa (*lasts, nail, strange, forum, batch...*) vì chỉ có khoảng 99 đánh giá Trung tính ở Train; dấu hiệu sớm cho thấy lớp này khó học.
""",
"PREP": """
> **Nhận xét:** Việc chọn cách scale dựa trên số liệu ở Train:
> - `day_diff` đã gần đối xứng (skew = 0.13) → **chỉ StandardScaler**, `log1p` sẽ làm lệch.
> - `word_count` (skew 9.14 → **0.66**) và `char_count` (9.36 → **0.55**) được `log1p` kéo về gần đối xứng; `exclaim_count` giảm từ 8.33 xuống 2.67.
> - Các cột bình chọn giảm mạnh (`helpful_yes` 34.6 → 10.1, `helpful_no` 30.1 → 10.1, `total_vote` 34.1 → 8.1) nhưng **vẫn lệch** vì đa số bằng 0 (cột có một "cột nhọn" tại 0, `log1p` không thể xử lý). `upper_ratio` cũng còn lệch (11.6 → 9.2).
""",
"PREP2": """
> **Nhận xét:** Ma trận đặc trưng Train có **3,438 mẫu × 5,008 đặc trưng** (5,000 TF-IDF + 8 số), độ thưa **99.3%** → dùng ma trận thưa và các mô hình tuyến tính/Naive Bayes là hợp lý. Số đặc trưng (5,008) lớn hơn số mẫu (3,438) nên cần điều chuẩn (tham số `C`/`alpha`) và đã được tinh chỉnh ở 3.3.
""",
"VAL": """
> **Nhận xét (Validation, 737 mẫu):**
> - **Dummy** đạt Accuracy 0.905 nhưng F1 macro chỉ 0.317. **LogReg mặc định** có F1 0.472 và F1 Trung tính = **0.000** (không bắt được đánh giá Trung tính nào).
> - **Xử lý mất cân bằng tăng F1 macro ở cả 3 thuật toán:** MultinomialNB 0.317 → **0.473**, LogReg 0.472 → **0.599**, LinearSVC 0.516 → **0.560**.
> - **F1 lớp Trung tính chỉ nhích lên ở LogReg (0 → 0.195) và LinearSVC (0 → 0.077)**; MultinomialNB vẫn bằng 0.
> - Cái giá phải trả: Recall tăng (LogReg 0.435 → 0.636) nhưng Accuracy giảm (0.925 → 0.910) vì mô hình báo nhầm nhiều đánh giá Tích cực thành Tiêu cực/Trung tính. LinearSVC giữ Accuracy 0.932.
""",
"TUNE": """
> **Nhận xét:**
> - Tham số tốt nhất: MultinomialNB `alpha=0.05, fit_prior=False`; LogReg `C=3, class_weight='balanced'`; LinearSVC `C=1, class_weight='balanced'`. **Cả ba đều chọn xử lý mất cân bằng** khi coi nó là siêu tham số.
> - CV F1 (Train): LogReg **0.585** > LinearSVC 0.562 > MultinomialNB 0.554. Trên Validation, F1 macro: LogReg **0.620** > LinearSVC 0.560 > MultinomialNB 0.527.
> - Tuning giúp LogReg rõ nhất (0.599 → 0.620, F1 Trung tính 0.195 → 0.235). LinearSVC không đổi vì `C=1` + `balanced` trùng với phiên bản mặc định đã chạy. MultinomialNB có Recall cao (0.620) nhưng Accuracy chỉ 0.858 do báo nhầm nhiều.
> - Chênh lệch giữa CV (0.585) và Validation (0.620) cho thấy ước lượng F1 dao động đáng kể vì lớp thiểu số quá ít mẫu.
""",
"META": """
> **Nhận xét:** Thêm meta-features **không cải thiện F1 macro**: LogReg 0.620 → 0.619 (gần như bằng nhau), LinearSVC 0.560 → 0.543 (giảm). ROC-AUC tăng ở cả hai (LogReg 0.878 → 0.894, LinearSVC 0.875 → 0.891), nhưng F1 Trung tính của LinearSVC tụt về 0.000.
> Phù hợp với mục 1.7: các đặc trưng số chỉ tương quan yếu với nhãn, thông tin đã nằm sẵn trong TF-IDF (độ dài ~ số từ). Nhóm vẫn đưa cả hai cấu hình vào bước chọn cuối để quyết định bằng số liệu.
""",
"FINAL": """
> **Nhận xét:** **LogisticRegression (tuned)** (`C=3`, `class_weight='balanced'`, chỉ TF-IDF) có F1 macro cao nhất trên Validation (**0.620**).
> Lưu ý: bản có meta-features (**0.619**) chỉ kém 0.001, thực chất là hòa, nên ưu tiên mô hình **đơn giản hơn** (không cần thêm 8 đặc trưng). Validation chỉ có 21 đánh giá Trung tính nên thứ hạng giữa các mô hình sát nhau không đáng tin tuyệt đối; điều này được kiểm tra lại trên Test ở Phần 4.
""",
"TEST": """
> **Nhận xét (Test, 737 mẫu, dùng một lần):**
> - Mô hình cuối: Accuracy **0.919**, F1 macro **0.593**, ROC-AUC macro **0.884**; cao hơn hẳn Dummy (F1 0.317) và LogReg baseline (F1 0.458).
> - Theo lớp: **Tiêu cực** F1 0.661 (Precision 0.578, Recall **0.771**); **Tích cực** F1 0.963; **Trung tính** F1 chỉ **0.154** (Precision 0.176, Recall 0.136).
> - ROC-AUC theo lớp: Tiêu cực **0.967**, Tích cực 0.939, Trung tính **0.745** → mô hình *xếp hạng* tốt đánh giá tiêu cực, nhưng gần như không tách được lớp Trung tính.
> - F1 trên Test (0.593) thấp hơn Validation (0.620), bình thường khi chỉ có 48 mẫu Tiêu cực và 22 mẫu Trung tính. LinearSVC (tuned) đạt 0.597 trên Test, hơn 0.004 và nằm trong sai số; nhóm **không đổi mô hình theo Test** vì mô hình đã được chốt trên Validation (đổi theo Test sẽ làm rò rỉ).
> - Accuracy (0.919) thấp hơn baseline (0.923): cái giá của việc ưu tiên bắt lớp thiểu số.
""",
"CREATIVE": """
> **Nhận xét (Test: 48 Tiêu cực, 22 Trung tính):**
> - **Bước 1 → 2 (class_weight):** số đánh giá Tiêu cực bắt được tăng **13 → 40** (Recall 0.27 → 0.83), F1 macro 0.458 → **0.577**. Đánh đổi: báo nhầm vào lớp Tiêu cực tăng **2 → 37** và vào lớp Trung tính **0 → 19**.
> - **Bước 2 → 3 (tuning):** bắt **37** Tiêu cực nhưng giảm báo nhầm (37 → **27**; Trung tính 19 → **14**), F1 macro **0.593**. Precision tiêu cực cải thiện (40/77 → 37/64 = 0.578).
> - **Lớp Trung tính:** chỉ bắt được **3/22 (13.6%)** dù đã xử lý mất cân bằng và tuning; baseline bắt **0**. Xử lý mất cân bằng giúp đáng kể với lớp Tiêu cực, nhưng **không đủ** với lớp Trung tính.
> - Tổng: cứ mỗi đánh giá Tiêu cực bắt thêm (13 → 37, +24) thì có thêm khoảng 25 cảnh báo sai (2 → 27); với bộ phận chăm sóc khách hàng, đây là đánh đổi có thể chấp nhận vì bỏ sót khiếu nại tốn kém hơn.
""",
"IMPORTANCE": """
> **Nhận xét:**
> - **Tiêu cực:** các từ về hỏng hóc/đòi quyền lợi: *died, dead, failed, stopped, refund, return, lost, message*, cụm *not recommend*, *does not*, *card failed*. Nhờ giữ từ phủ định ở bước làm sạch, các cụm này mới xuất hiện được.
> - **Tích cực:** *great, works, works great, fast, good, best, love, price, space*, và cụm *no problems* (từ `no` được giữ lại nhờ `KEEP_WORDS`).
> - **Trung tính:** từ yếu và phân tán (*but not, though, job, expectations, twice, stores, flexibility*): vài từ mang tính "tạm được/có điều kiện" nhưng nhiều từ có vẻ ngẫu nhiên, vì lớp này chỉ có khoảng 99 mẫu Train. Điều này lý giải vì sao Trung tính là lớp khó nhất.
""",
"ERROR": """
> **Nhận xét:**
> - **Theo điểm sao (Test):** 1★ đúng 77.1% (n=35), 2★ 76.9% (n=13), **3★ chỉ 13.6% (n=22)**, 4★ 90.1% (n=81), 5★ 96.2% (n=586). Lỗi tập trung ở 3 sao: 22 đánh giá 3★ bị đoán 7 Tiêu cực, 3 Trung tính, 12 Tích cực.
> - **Theo độ dài:** đánh giá dài nhất (54–449 từ) đúng **80.4%** so với 94–97% ở ba nhóm ngắn hơn: đánh giá dài thường vừa khen vừa chê.
> - **Các kiểu nhầm lẫn (số mẫu):** Tích cực → Tiêu cực **20**, Trung tính → Tích cực **12**, Tích cực → Trung tính 10, Tiêu cực → Tích cực 7, Trung tính → Tiêu cực 7, Tiêu cực → Trung tính 4. Số ca Tích cực → Tiêu cực lớn nhất chính là hệ quả của `class_weight`: 14 đánh giá 5★ bị báo Tiêu cực.
> - **Ca "tự tin nhưng sai":** (1) đánh giá 1★ than phiền về *giá tăng* nhưng không dùng từ cảm xúc nào; (2) đánh giá bắt đầu bằng lời khen SanDisk rồi mới chê ("*SanDisk is one of the best... but very dissapointed*"); (3) cách nói ẩn dụ ("*Passed away... RIP*"); (4) một ca 2★ nói thẻ hỏng ba lần vẫn bị đoán Tích cực. Mô hình túi từ (bag-of-words) không hiểu ngữ cảnh, mỉa mai hay ẩn dụ.
> - Một phần "lỗi" đến từ **nhãn nhiễu** vì nhãn lấy từ điểm sao: người dùng chấm 3–4 sao vẫn có thể viết nội dung chê.
""",
"EXTERNAL": """
> **Nhận xét (5,000 đánh giá ngoài, nhiều ngành hàng; 40% Tiêu cực / 20% Trung tính / 40% Tích cực):**
> - **Giả định gộp nhãn hợp lý:** tỉ lệ bị đoán "Tích cực" tăng đơn điệu theo nhãn gốc 0→4: **63%, 70%, 81%, 91%, 96%**. Tuy nhiên 63% đánh giá 1 sao bị đoán Tích cực → mô hình **kém hẳn khi đổi miền**.
> - **Hiệu năng giảm mạnh:** mô hình cuối (LogReg tuned) có F1 macro **0.389** (Accuracy 0.496, ROC-AUC 0.729), so với 0.593 trên Test. Cả 6 mô hình trong bảng đều có ROC-AUC chỉ khoảng 0.70–0.73.
> - **Xếp hạng đảo ngược:** MultinomialNB (tuned) là mô hình tốt nhất ở tập ngoài (F1 **0.517**, F1 Trung tính 0.294) dù là mô hình thấp nhất trong nhóm đã tuning ở Validation (F1 0.527) và ở Test (0.518, so với LinearSVC 0.597). Có thể vì nó dùng tiên nghiệm đều (`fit_prior=False`) nên ít bị kéo về lớp Tích cực (90% ở dữ liệu huấn luyện).
> - **Nguyên nhân có thể:** từ vựng học từ thẻ nhớ (*card, fast, space, works*) không chuyển sang ngành hàng khác; ngoài ra phân bố lớp ở tập ngoài (40/20/40) rất khác khi huấn luyện (90/3/7), nên prior của mô hình lệch.
""",
"TRANSFORMER": """
> **Nhận xét:** Ô trên chỉ chạy khi môi trường có `torch`, `transformers` và internet (để tải mô hình ~500 MB); nếu không thì tự bỏ qua mà không ảnh hưởng phần còn lại.
> **Bản notebook đã chạy sẵn trong repo được tạo ở môi trường không có `torch`, nên ô này in thông báo bỏ qua và chưa có số liệu RoBERTa**; vì vậy nhóm không đưa ra kết luận nào về Transformer từ bản này. Để có kết quả: `pip install torch transformers` rồi chạy lại notebook; bảng so sánh F1 macro, F1 Trung tính giữa ML truyền thống và RoBERTa sẽ tự hiện ra.
""",
"CONCLUSION": """
**Kết quả chính (mô hình cuối: Logistic Regression, `C=3`, `class_weight='balanced'`, TF-IDF 5,000 đặc trưng, 1–2-gram):**
- Test: Accuracy **0.919**, F1 macro **0.593**, ROC-AUC macro **0.884**; tốt hơn Dummy (F1 0.317) và LogReg mặc định (F1 0.458).
- Câu hỏi 1 (từ phân biệt): Tiêu cực ↔ từ hỏng hóc/đòi hoàn tiền và phủ định (*died, failed, refund, not recommend*); Tích cực ↔ *great, works, fast, no problems*; Trung tính không có từ đặc trưng rõ.
- Câu hỏi 2 (mất cân bằng ~90%): `class_weight='balanced'` tăng số đánh giá Tiêu cực bắt được từ **13 lên 37 trong 48** (và F1 macro từ 0.458 lên 0.593), đổi lại số báo nhầm vào lớp Tiêu cực tăng từ 2 lên 27. Với lớp Trung tính chỉ bắt được **3/22**.
- Meta-features (độ dài, số dấu `!`, bình chọn...) **không giúp** F1 macro (0.620 → 0.619).

**Hạn chế:**
- **Lớp Trung tính chỉ có 142 mẫu** (22 mẫu ở Test): mọi con số của lớp này có sai số rất lớn.
- Nhãn suy ra từ điểm sao nên có nhiễu; mô hình túi từ không hiểu ngữ cảnh/mỉa mai/ý vừa khen vừa chê.
- **Không tổng quát hóa sang ngành hàng khác:** F1 macro giảm từ 0.593 (Test) xuống 0.389 (tập ngoài); dữ liệu huấn luyện chủ yếu là thẻ nhớ.
- Mục 4.6 (Transformer) chưa có số liệu trong bản đã chạy do môi trường không có `torch`.

**Hướng phát triển:** thu thập thêm đánh giá Trung tính; thử SMOTE/tăng cường dữ liệu; tinh chỉnh ngưỡng quyết định theo từng lớp; dùng embedding hoặc fine-tune Transformer; huấn luyện trên dữ liệu đa ngành hàng.
""",
}


def note(key):
    return NOTES.get(key, f"> **Nhận xét ({key}):** _(chưa điền)_").strip("\n")
