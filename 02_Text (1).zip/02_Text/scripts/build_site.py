"""Ghép notebook đã chạy (có output) vào trang chủ -> docs/index.html (MỘT file duy nhất, không cần CDN ngoài).

Chạy từ thư mục 02_Text, sau khi đã có notebooks/02_Text_Amazon_Reviews.ipynb:
    python scripts/build_site.py
"""
import re
from pathlib import Path

import nbformat
from nbconvert import HTMLExporter
from pygments.formatters import HtmlFormatter

ROOT = Path(__file__).resolve().parent.parent
NB = ROOT / 'notebooks' / '02_Text_Amazon_Reviews.ipynb'
TEMPLATE = ROOT / 'scripts' / 'site_template.html'
OUT = ROOT / 'docs' / 'index.html'


def main():
    nb = nbformat.read(NB, 4)
    body, _ = HTMLExporter(template_name='basic').from_notebook_node(nb)
    body = re.sub(r'<script.*?</script>', '', body, flags=re.S)      # bỏ script (require.js, MathJax) để trang nhẹ và tải một lần
    pyg = HtmlFormatter(style='default').get_style_defs('.nb .highlight')
    page = TEMPLATE.read_text(encoding='utf-8').replace('<!--NOTEBOOK-->', body).replace('/*PYGMENTS*/', pyg)
    OUT.write_text(page, encoding='utf-8')
    print(f'Đã ghi {OUT.relative_to(ROOT)} ({OUT.stat().st_size / 1024:.0f} KB)')


if __name__ == '__main__':
    main()
